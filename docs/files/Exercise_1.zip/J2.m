function [f] = J2(p1,p2)
f = 100.*(p2 - p1.^2).^2 + (1 - p1).^2;
end

