function [cost] = Jtemplate(p)
p1 = p(1);
p2 = p(2);
cost = p1^2 + p2^2;

