function [cost grad hessian] = Jquad(p)
p1 = p(1);
p2 = p(2);
cost = p1^2 + p2^2 + p1*p2 + p2;
grad = [2*p1 + p2 ; 2*p2 + p1 + 1];
hessian = [2  1 ; 1 2 ];

