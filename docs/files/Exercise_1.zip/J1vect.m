function [cost]=J1vect(p)
cost=J1(p(1),p(2));
