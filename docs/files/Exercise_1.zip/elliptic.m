ezplot(@(p1,p2)arrayfun(@(p1,p2)[p1 p2]*h*[p1;p2]-1,p1,p2));
