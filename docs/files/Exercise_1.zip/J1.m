function [cost]=J1(p1,p2)
cost=p1.^2+exp(p2)+exp(-p2)+p1.*p2+p2;
