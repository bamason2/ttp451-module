function [stop]=myplot(x,o,v)
hold('on');
plot([x(1)],[x(2)],'*r');
stop=0;