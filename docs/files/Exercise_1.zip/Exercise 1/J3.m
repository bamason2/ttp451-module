function [cost]=J3(p1,p2)
cost = J1(p1,p2) - 10 .* cos(2.*p1) .* cos(2.*p2);