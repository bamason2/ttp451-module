function [f]=J3vect(p)
f = J3(p(1),p(2));