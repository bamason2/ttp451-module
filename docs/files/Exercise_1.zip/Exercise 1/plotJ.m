ezcontour('arrayfun(@(p1,p2)J([p1 p2]),p1,p2)');
