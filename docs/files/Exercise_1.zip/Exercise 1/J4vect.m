function [cost]=J4vect(p)
cost=J4(p(1),p(2));
