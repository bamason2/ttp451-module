function [cost]=J4(p1,p2)
alpha = 10;
cost = alpha.*(50./p1 + 50./p2) + (5.*p1.^2 + 4.*p2.^2)./3600;
