
function polyfit_lab_v3()

%-----   csv read - Follow step 2

%-----   data filter - Follow step 3

%-----   data sort - Follow step 4

for n=1:4
[BMEP_poly{n}, BMEP_data_poly(:,n)] = poly_fitting(mydata(:,6),mydata(:,13),n);
[Exh_poly{n}, Exh_data_poly(:,n)] = poly_fitting(mydata(:,9),mydata(:,11),n); 
end

%Calculate R2 and residual
for n=1:4
[R2_BMEP(:,n), resid_BMEP(:,n)] = error_evaluation(mydata(:,13),BMEP_data_poly(:,n));
[R2_Exh(:,n), resid_Exh(:,n)] = error_evaluation(mydata(:,11),Exh_data_poly(:,n));
end

%-----    Plot functions - Step 5(Create your own code)

function [model, model_predict] = poly_fitting(input,response,n) 

switch n
    case 1
        poly_order = 'poly1';
    case 2
        poly_order = 'poly2';
    case 3
        poly_order = 'poly3';
    case 4
        poly_order = 'poly4';
end

model=fit(input,response,poly_order);
model_predict = model(input);

function [Rsqred, resid] = error_evaluation(actual_data,predict_data)
resid = actual_data - predict_data;
SSresid = sum(resid.^2);
SStotal = (length(actual_data)-1) * var(actual_data);
Rsqred = 1 - SSresid/SStotal;