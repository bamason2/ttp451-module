
% Title: Manual RBF tuning
% Prepared by: Farraen Mohd Azmin
% Course: Calibration and Emissions MSc module
% Date: 09-12-2013

%Set input resolution
x=-2:0.1:2;

%Target function
target = -0.25*x.^4 + 0.4167*x.^3 + x.^2 -0.6667*x + 2;

%RBF Widths(To be tuned by students)
wd_0 = 1;
wd_1 = 1;
wd_2 = 1;
wd_3 = 1;
wd_4 = 1;

%RBF Centers(To be tuned by students)
xi_0 = -2;
xi_1 = -1;
xi_2 = 0;
xi_3 = 1;
xi_4 = 2;

%RBF Weights(To be tuned by students)
w_0 = 1;
w_1 = 1;
w_2 = 1;
w_3 = 1;
w_4 = 1;

%Radial basis function with gaussian kernel
zz_0 = w_0 * exp(-(x-xi_0).^2/wd_0^2);
zz_1 = w_1 * exp(-(x-xi_1).^2/wd_1^2);
zz_2 = w_2 * exp(-(x-xi_2).^2/wd_2^2);
zz_3 = w_3 * exp(-(x-xi_3).^2/wd_3^2);
zz_4 = w_4 * exp(-(x-xi_4).^2/wd_4^2);

%Radial basis network
zz_8 = zz_0 + zz_1 + zz_2 + zz_3 + zz_4;

%Plot radial basis function
figure(1);
plot(x,target,'r',x,zz_8,'b',x,zz_0,'g',x,zz_1,'g',x,zz_2,'g',x,zz_3,'g',x,zz_4,'g');
title('Radial Basis Function Exercise')
xlabel('X'), ylabel('Y')
legend('Target','Sum of RBF','Local RBF');
grid on;
