
% Author: Farraen Mohd Azmin
% Email: F.Mohd-Azmin@lboro.ac.uk
% Company: Loughborough University
% Prepared for: Calibration and Emissions MSc module
% Date: 3-1-2014
% Title: Initialization sequences for virtual engine model for
%        generating experimental test results

clc;
clear all;

%Load csv file
filename = 'V8NA_TestBed_DoE.csv';
V8NA_TestBed_DoE = csvread(filename,1,0);

%Get dataset array dimensions
col_size = size(V8NA_TestBed_DoE, 1); 

%Generate time stamp for dataset
for j=1:1:col_size
    timeArr(j,1) = j;
end

%Add time stamp array to DOE array
V8NA_TestBed_DoE = [timeArr V8NA_TestBed_DoE];

clear ('col_size', 'j', 'timeArr', 'filename');

