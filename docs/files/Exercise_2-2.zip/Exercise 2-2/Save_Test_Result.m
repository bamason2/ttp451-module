
% Author: Farraen Mohd Azmin
% Email: F.Mohd-Azmin@lboro.ac.uk
% Company: Loughborough University
% Prepared for: Calibration and Emissions MSc module
% Date: 3-1-2014
% Title: Save test result in csv format

%Save csv file

clc;
filename = 'V8NA_TestBed_Data.csv'; 
fileID = fopen(filename,'wt');

V8NA_TestBed_Data(V8NA_TestBed_Data(:,2)<0,:) = [];

label = {'EngineSpeed','RelativeLoad','IntakeCAM','ExhaustCAM',...
    'SparkAngle','FuelRailPres','InjectAngle','Lambda',...
    'BMEP_mean','BMEP_sigma','ExhaustTemp','IntakeFuelMass'};		

[rows, columns] = size(label);
for index = 1:rows    
    fprintf(fileID, '%s,', label{index,1:end-1});
    fprintf(fileID, '%s\n', label{index,end});
end 

fclose(fileID);
dlmwrite(filename, V8NA_TestBed_Data,'-append', 'delimiter', ',');